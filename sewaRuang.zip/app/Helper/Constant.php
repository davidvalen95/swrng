<?php
/**
 * Created by PhpStorm.
 * User: Valkeyri
 * Date: 1/28/2018
 * Time: 11:35 PM
 */


define("EMAIL_INFO","info@sewaruang.id");
define("PER_PAGE",50);
define("IS_SERVER",false);