
<footer>
    <section class='container'>
        <section class='row'>
            <div class='span4 footer-widget'>
                <h2>About Us</h2>

                <p>Donec ac diam nec magna dignissim porta ut eu nulla. Cras neque metus, dictum et congue ac, tristique eget ante. In hac habitasse platea dictumst.</p>

                <p>Quisque tincidunt ornare sapien, at commodo ante tristique non. Integer id tellus nisl. Donec eget nunc eget odio malesuada egestas.</p>
                <a href="#" class='read-more'>Learn More</a>
            </div>
            <div class='span4 footer-widget'>
                <h2>Recent News</h2>

                <div class='blog-style'>
                    <article>
                        <div class='date-box'>
                            <div class='day'>20</div>
                            <div class='month'>mar</div>
                        </div>
                        <div class='text-box'>
                            <h3><a href="post.html">How to Choose Property</a></h3>
                            <span class='author'>posted by admin</span>

                            <div class='excerpt'>
                                <p>In porttitor augue vel velit luctus at scelerisque nisi dictum. Ut tempus dignissim mi, at gravida leo.</p>
                            </div>
                        </div>
                    </article>
                    <article>
                        <div class='date-box'>
                            <div class='day'>16</div>
                            <div class='month'>mar</div>
                        </div>
                        <div class='text-box'>
                            <h3><a href="post.html">Real Estate of Future</a></h3>
                            <span class='author'>posted by admin</span>

                            <div class='excerpt'>
                                <p>In porttitor augue vel velit luctus at scelerisque nisi dictum. Ut tempus dignissim mi, at gravida leo.</p>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
            <div class='span4 footer-widget'>
                <h2>Testimonials</h2>

                <div class='testimonial-box'>
                    <div class='controls'>
                        <a href="#" class='prev'>Previous</a>
                        <a href="#" class='next'>Next</a>
                    </div>
                    <ul class='slides'>
                        <li>
                            <div class='slide-box'>
                                <div class='text-box'>
                                    <div class='inner'>
                                        <p>"Quisque venenatis dui vitae augue accumsan sed blandit lectus pretium. Vivamus at urna ut est faucibus ornare in quis lacus. Praesent erat nulla, venenatis
                                            ac consequat vel, vestibulum id massa."</p>
                                    </div>

                                </div>
                                <div class='author-box'>
                                    <figure></figure>
                                    <div class='texts'>
                                        <span class='name'>John Doe</span> <br/>
                                        <span class='position'>Company name</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class='slide-box'>
                                <div class='text-box'>
                                    <div class='inner'>
                                        <p>Donec ac diam nec magna dignissim porta ut eu nulla. Cras neque metus, dictum et congue ac, tristique eget ante. In hac habitasse platea dictumst.</p>
                                    </div>

                                </div>
                                <div class='author-box'>
                                    <figure></figure>
                                    <div class='texts'>
                                        <span class='name'>John Doe</span> <br/>
                                        <span class='position'>Company name</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <i class='footer-bubble'></i>
        </section>
    </section>
</footer>
<section id='sub-footer'>
    <section class='container'>
        <section class='row'>
            <div class='span3'>
                <figure class='logo'>
                    <a href="index-2.html">
                        <img src="img/logo-footer.png" alt=""/>
                    </a>
                </figure>
            </div>
            <div class='span6'>
                <div class='copyright'>
                    <p>&copy; 2013 Unreal Estate. All rights reserved. Developed by <a href="http://teothemes.com/">TeoThemes</a></p>
                </div>
            </div>
            <div class='span3'>
                <div class='social-icons'>
                    <a href="#" class='be'>Be</a>
                    <a href="#" class='star'>Star</a>
                    <a href="#" class='pinterest'>Pinterest</a>
                    <a href="#" class='facebook'>Facebook</a>
                    <a href="#" class='twitter'>Twitter</a>
                </div>
            </div>
        </section>
    </section>
</section>