<?php

    /** @var App\Model\Room[] $rooms */
    /** @var App\Model\Room $room */
?>

<div class='span9 featured-item-wrapper featured-item-list'>
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php

        $room->setDefaultPreference();
    ?>

    <div class='featured-item featured-list'>
        <div class='top'>
            <div class='inner-border'>
                <div class='inner-padding'>
                    <figure >
                        <img   class="img-responsive" src="<?php echo e($room->getPhotos->where('isMain',true)->first()->getSmall()); ?>" alt="" />
                        <div class='banner'></div>
                        <a href="#" class='figure-hover'>Zoom</a>
                    </figure>
                    <div class='right'>
                        <h3><a  href="<?php echo e(route("get.roomDetail",[$room->id])); ?>"><?php echo e($room->roomFunction); ?></a></h3>
                        <p><?php echo e($room->buildingName); ?> - <?php echo e($room->roomName); ?>, <?php echo e($room->city); ?></p>
                        <p><b>Deskripsi</b></p>
                        <div class='description'>
                            <p><?php echo e($room->description); ?></p>
                        </div>
                        <div class='price-wrapper'>
                            <div class='price'>Rp. <?php echo e($room->mainPrice); ?></div>
                            <div class='rate'>/jam</div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        
            
                
                    
                    
                        
                        
                        
                        
                        
                    
                
            
        
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>