

<?php
/** @var App\Model\Room[] $rooms */
/** @var App\Model\Photo $photo */

?>


    <div class='description-box open' rel='1'>


            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class='inner' style="">
                <div class='inner-container'>
                    <div style="display:block">

                        

                        <h2><?php echo e($room->roomName); ?></h2>
                        <?php ($photo = $room->getPhotos->where('isMain',true)->first()); ?>
                        
                        <?php ($room->setDefaultPreference()); ?>
                        <?php if($photo): ?>
                            
                        <a class="image-link" href="<?php echo e($photo->getLarge()); ?>"><div style="max-width:450px;max-height:200px; overflow:hidden; float:left; padding-right: 16px;">
                            <img class="img-responsive" alt="" src="<?php echo e($photo->getSmall()); ?>" />

                            </div></a>


                        <?php endif; ?>
                        <p style="margin-bottom:-2px;"><?php echo e($room->buildingName); ?>, <?php echo e($room->city); ?></p>
                        <p style="margin-bottom:0px;">Harga Per Jam: Rp.<?php echo e($room->mainPrice); ?></p>
                        
                        <a href="<?php echo e(route('get.roomDetail',[$room->id])); ?>">Detail Ruangan</a>
                        <div class='list-container'>
                            <ul class='custom-list'>
                              </ul>
                        </div>
                    </div>

                    <div style="display:block">
                        
                    </div>
                    

                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(sizeof($rooms)== 0): ?>
            <p style="padding:16px;">
                Saat ini anda belum memiliki ruangan yang dipasang
            </p>
            
        <?php endif; ?>
    </div>

