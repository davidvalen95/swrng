<?php $__env->startSection('content'); ?>

    <section id='page-title' class='small-height'>
        <section class='container'>
            <section class='row'>
                <div class='span8'>
                    <h1>My Room</h1>
                    <p>Anda dapat melihat ruangan-ruangan anda di sini</p>
                </div>
            </section>
        </section>
    </section>
    <section class='about-slider'>
        <section class='container'>
            <section class='row'>
                <div class='span9'>
                    <div class='description-box open' rel='1'>
                        <div class='inner'>
                            <div class='inner-container'>
                                <div style="display:block">

                                        <img alt="" src="img/photos/4947806065_f932310392_b.jpg" />

                                    <h2>Nama Room</h2>
                                    <p>Description</p>
                                    <div class='list-container'>
                                        <ul class='custom-list'>
                                            <li><a href="#">List style example</a></li>
                                            <li><a href="#">List style example</a></li>
                                            <li><a href="#">List style example</a></li>
                                            <li><a href="#">List style example</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div style="display:block">
                                    <p>1Ut lobortis velit nec orci adipiscing id pellentesque lacus fermentum. Etiam vitae ante sapien, nec molestie nisi. Mauris purus tellus, luctus quis accumsan vel, pretium eu velit. Sed mattis, nunc et iaculis adipiscing, diam diam gravida augue, ut suscipit ipsum arcu vel metus.</p>
                                    <p>2Ut lobortis velit nec orci adipiscing id pellentesque lacus fermentum. Etiam vitae ante sapien, nec molestie nisi. Mauris purus tellus, luctus quis accumsan vel, pretium eu velit. Sed mattis, nunc et iaculis adipiscing, diam diam gravida augue, ut suscipit ipsum arcu vel metus.</p>
                                    <p>31Ut lobortis velit nec orci adipiscing id pellentesque lacus fermentum. Etiam vitae ante sapien, nec molestie nisi. Mauris purus tellus, luctus quis accumsan vel, pretium eu velit. Sed mattis, nunc et iaculis adipiscing, diam diam gravida augue, ut suscipit ipsum arcu vel metus.</p>
                                    <p>4Ut lobortis velit nec orci adipiscing id pellentesque lacus fermentum. Etiam vitae ante sapien, nec molestie nisi. Mauris purus tellus, luctus quis accumsan vel, pretium eu velit. Sed mattis, nunc et iaculis adipiscing, diam diam gravida augue, ut suscipit ipsum arcu vel metus.</p>

                                </div>
                                <blockquote>Aliquam placerat, quam eu volutpat lobortis, elit massa porttitor nisl, sed bibendum est massa in orci. Fusce odio sed nunc scelerisque lacinia.</blockquote>
                            </div>
                        </div>
                    </div>
                    <div class='description-box' rel='2'>
                        <div class='inner'>
                            <div class='inner-container'>
                                <figure>
                                    <img src="img/photos/4834826842_cdeb5bc8be_b.jpg" alt="" />
                                </figure>
                                <h2>Strategy</h2>
                                <p>Aenean dignaissim luctus ipsum a convallis. Pellentesque vehicula urna et dolor consectetur nec fermentum dui faucibus. Aenean porttitor ullamcorper velit non tristique. </p>
                                <div class='list-container'>
                                    <ul class='custom-list'>
                                        <li><a href="#">List style example</a></li>
                                        <li><a href="#">List style example</a></li>
                                        <li><a href="#">List style example</a></li>
                                        <li><a href="#">List style example</a></li>
                                    </ul>
                                </div>
                                <p>Ut lobortis velit nec orci adipiscing id pellentesque lacus fermentum. Etiam vitae ante sapien, nec molestie nisi. Mauris purus tellus, luctus quis accumsan vel, pretium eu velit. Sed mattis, nunc et iaculis adipiscing, diam diam gravida augue, ut suscipit ipsum arcu vel metus.</p>
                                <blockquote>Aliquam placerat, quam eu volutpat lobortis, elit massa porttitor nisl, sed bibendum est massa in orci. Fusce odio sed nunc scelerisque lacinia.</blockquote>
                            </div>
                        </div>
                    </div>
                    <div class='description-box' rel='3'>
                        <div class='inner'>
                            <div class='inner-container'>
                                <figure>
                                    <img src="img/photos/4834812234_3379989227_b.jpg" alt="" />
                                </figure>
                                <h2>Tools</h2>
                                <p>Aenean dignaissim luctus ipsum a convallis. Pellentesque vehicula urna et dolor consectetur nec fermentum dui faucibus. Aenean porttitor ullamcorper velit non tristique. </p>
                                <div class='list-container'>
                                    <ul class='custom-list'>
                                        <li><a href="#">List style example</a></li>
                                        <li><a href="#">List style example</a></li>
                                        <li><a href="#">List style example</a></li>
                                        <li><a href="#">List style example</a></li>
                                    </ul>
                                </div>
                                <p>Ut lobortis velit nec orci adipiscing id pellentesque lacus fermentum. Etiam vitae ante sapien, nec molestie nisi. Mauris purus tellus, luctus quis accumsan vel, pretium eu velit. Sed mattis, nunc et iaculis adipiscing, diam diam gravida augue, ut suscipit ipsum arcu vel metus.</p>
                                <blockquote>Aliquam placerat, quam eu volutpat lobortis, elit massa porttitor nisl, sed bibendum est massa in orci. Fusce odio sed nunc scelerisque lacinia.</blockquote>
                            </div>
                        </div>
                    </div>
                    <div class='description-box' rel='4'>
                        <div class='inner'>
                            <div class='inner-container'>
                                <figure>
                                    <img src="img/photos/4834790926_0228ed6cde_b.jpg" alt="" />
                                </figure>
                                <h2>Methodology</h2>
                                <p>Aenean dignaissim luctus ipsum a convallis. Pellentesque vehicula urna et dolor consectetur nec fermentum dui faucibus. Aenean porttitor ullamcorper velit non tristique. </p>
                                <div class='list-container'>
                                    <ul class='custom-list'>
                                        <li><a href="#">List style example</a></li>
                                        <li><a href="#">List style example</a></li>
                                        <li><a href="#">List style example</a></li>
                                        <li><a href="#">List style example</a></li>
                                    </ul>
                                </div>
                                <p>Ut lobortis velit nec orci adipiscing id pellentesque lacus fermentum. Etiam vitae ante sapien, nec molestie nisi. Mauris purus tellus, luctus quis accumsan vel, pretium eu velit. Sed mattis, nunc et iaculis adipiscing, diam diam gravida augue, ut suscipit ipsum arcu vel metus.</p>
                                <blockquote>Aliquam placerat, quam eu volutpat lobortis, elit massa porttitor nisl, sed bibendum est massa in orci. Fusce odio sed nunc scelerisque lacinia.</blockquote>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='span3'>
                    <div class='description-controls'>
                        <ul>
                            <li><a href="#" rel='1' class='active'>How We Work</a></li>
                            <li><a href="#" rel='2'>Strategy</a></li>
                            <li><a href="#" rel='3'>Tools</a></li>
                            <li><a href="#" rel='4'>Methodology</a></li>
                        </ul>
                    </div>
                </div>
            </section>
        </section>
    </section>
    <section class='full-width'>
        <section class='container'>
            <section class='row'>
                <div class='span4'>
                    <h2>How We Work</h2>
                    <p>Aenean dignissim luctus ipsum a convallis. Pellentesque vehicula urna et dolor consectetur nec fermentum dui faucibus. </p>
                    <a href="#" class='read-more'>Learn More</a>
                </div>
                <div class='span4'>
                    <ul class='big-numbers'>
                        <li>
                            <span class='number'>1.</span> <div class='text'>Proin congue arcu libero. Sed placerat, sapien eu imperdiet scelerisque, arcu diam eleifend lorem, non vestibulum.</div>
                        </li>
                        <li>
                            <span class='number'>2.</span> <div class='text'>Proin congue arcu libero. Sed placerat, sapien eu imperdiet scelerisque, arcu diam eleifend lorem, non vestibulum.</div>
                        </li>
                        <li>
                            <span class='number'>3.</span> <div class='text'>Proin congue arcu libero. Sed placerat, sapien eu imperdiet scelerisque, arcu diam eleifend lorem, non vestibulum.</div>
                        </li>
                    </ul>
                </div>
                <div class='span4'>
                    <ul class='big-numbers'>
                        <li>
                            <span class='number'>4.</span> <div class='text'>Proin congue arcu libero. Sed placerat, sapien eu imperdiet scelerisque, arcu diam eleifend lorem, non vestibulum.</div>
                        </li>
                        <li>
                            <span class='number'>5.</span> <div class='text'>Proin congue arcu libero. Sed placerat, sapien eu imperdiet scelerisque, arcu diam eleifend lorem, non vestibulum.</div>
                        </li>
                        <li>
                            <span class='number'>6.</span> <div class='text'>Proin congue arcu libero. Sed placerat, sapien eu imperdiet scelerisque, arcu diam eleifend lorem, non vestibulum.</div>
                        </li>
                    </ul>
                </div>
            </section>
        </section>
    </section>
    <section id='content' class='alternate-bg'>
        <section class='container'>
            <section class='row featured-items'>
                <div class='span12'>
                    <div class='stats5'>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>3k</span>
                                <span class='text'>Items in Database</span>
                            </div>
                        </div>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>300</span>
                                <span class='text'>Happy Clients</span>
                            </div>
                        </div>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>60</span>
                                <span class='text'>Experienced Agents</span>
                            </div>
                        </div>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>58</span>
                                <span class='text'>Searches per hour</span>
                            </div>
                        </div>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>786</span>
                                <span class='text'>Months of Activity</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='span12'>
                    <div class="hero-unit">
                        <h1>Sed tortor nulla, vehicula hendrerit pretium</h1>
                        <p>Maecenas accumsan libero sed <strong>nunc ultricies eget molestie</strong> purus blandit. Maecenas lobortis vulputate tortor eget cursus. Curabitur a semper orci.</p>
                        <p>
                            <a class="btn btn-primary btn-large">
                                Learn more
                            </a>
                        </p>
                    </div>
                </div>

            </section>
        </section>
    </section>
    <footer>
        <section class='container'>
            <section class='row'>
                <div class='span4 footer-widget'>
                    <h2>About Us</h2>

                    <p>Donec ac diam nec magna dignissim porta ut eu nulla. Cras neque metus, dictum et congue ac, tristique eget ante. In hac habitasse platea dictumst.</p>

                    <p>Quisque tincidunt ornare sapien, at commodo ante tristique non. Integer id tellus nisl. Donec eget nunc eget odio malesuada egestas.</p>
                    <a href="#" class='read-more'>Learn More</a>
                </div>
                <div class='span4 footer-widget'>
                    <h2>Recent News</h2>

                    <div class='blog-style'>
                        <article>
                            <div class='date-box'>
                                <div class='day'>20</div>
                                <div class='month'>mar</div>
                            </div>
                            <div class='text-box'>
                                <h3><a href="post.html">How to Choose Property</a></h3>
                                <span class='author'>posted by admin</span>

                                <div class='excerpt'>
                                    <p>In porttitor augue vel velit luctus at scelerisque nisi dictum. Ut tempus dignissim mi, at gravida leo.</p>
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class='date-box'>
                                <div class='day'>16</div>
                                <div class='month'>mar</div>
                            </div>
                            <div class='text-box'>
                                <h3><a href="post.html">Real Estate of Future</a></h3>
                                <span class='author'>posted by admin</span>

                                <div class='excerpt'>
                                    <p>In porttitor augue vel velit luctus at scelerisque nisi dictum. Ut tempus dignissim mi, at gravida leo.</p>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
                <div class='span4 footer-widget'>
                    <h2>Testimonials</h2>

                    <div class='testimonial-box'>
                        <div class='controls'>
                            <a href="#" class='prev'>Previous</a>
                            <a href="#" class='next'>Next</a>
                        </div>
                        <ul class='slides'>
                            <li>
                                <div class='slide-box'>
                                    <div class='text-box'>
                                        <div class='inner'>
                                            <p>"Quisque venenatis dui vitae augue accumsan sed blandit lectus pretium. Vivamus at urna ut est faucibus ornare in quis lacus. Praesent erat nulla, venenatis
                                                ac consequat vel, vestibulum id massa."</p>
                                        </div>

                                    </div>
                                    <div class='author-box'>
                                        <figure></figure>
                                        <div class='texts'>
                                            <span class='name'>John Doe</span> <br/>
                                            <span class='position'>Company name</span>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class='slide-box'>
                                    <div class='text-box'>
                                        <div class='inner'>
                                            <p>Donec ac diam nec magna dignissim porta ut eu nulla. Cras neque metus, dictum et congue ac, tristique eget ante. In hac habitasse platea dictumst.</p>
                                        </div>

                                    </div>
                                    <div class='author-box'>
                                        <figure></figure>
                                        <div class='texts'>
                                            <span class='name'>John Doe</span> <br/>
                                            <span class='position'>Company name</span>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <i class='footer-bubble'></i>
            </section>
        </section>
    </footer>
    <section id='sub-footer'>
        <section class='container'>
            <section class='row'>
                <div class='span3'>
                    <figure class='logo'>
                        <a href="index-2.html">
                            <img src="img/logo-footer.png" alt=""/>
                        </a>
                    </figure>
                </div>
                <div class='span6'>
                    <div class='copyright'>
                        <p>&copy; 2013 Unreal Estate. All rights reserved. Developed by <a href="http://teothemes.com/">TeoThemes</a></p>
                    </div>
                </div>
                <div class='span3'>
                    <div class='social-icons'>
                        <a href="#" class='be'>Be</a>
                        <a href="#" class='star'>Star</a>
                        <a href="#" class='pinterest'>Pinterest</a>
                        <a href="#" class='facebook'>Facebook</a>
                        <a href="#" class='twitter'>Twitter</a>
                    </div>
                </div>
            </section>
        </section>
    </section>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>