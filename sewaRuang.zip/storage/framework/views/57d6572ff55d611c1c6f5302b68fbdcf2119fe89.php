

<?php

/** @var App\Model\Room $room */

?>
<div class='description-box' rel='2'>
    <div class='contact-box'>
        <div class='title-bar'>
            <div class='inner'  style="border:0px !important;" >

                <h2><?php echo e($isEdit ? "Edit $room->roomName - $room->buildingName" : "Silahkan isi form di bawah ini untuk menambahkan ruangan baru"); ?></h2>
                <p>Isi data ruangan selengkap-lengkapnya agar informatif. Masukan foto terbaik agar menarik.</p>
            </div>
        </div>
        <div class='contact-box-content'>
            <div class='inner'>
                <div class=''>


                    <?php

                    ?>
                    <form id="parentForm" enctype="multipart/form-data" action="<?php echo e(route('post.addRoom')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        
                        
                        
                        
                        
                        
                        
                        
                        
                            
                        

                        <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $form->getOutput(); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <?php if($isEdit): ?>
                            <?php $__currentLoopData = $room->getPhotos->where('isMain',false)->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currentPhoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="photo<?php echo e($currentPhoto->id); ?>" style="margin-bottom: 12px; ">
                                <img style="max-height: 150px;" src="<?php echo e($currentPhoto->getSmall()); ?>"/>
                                <br/>
                                <button data-parrent="photo<?php echo e($currentPhoto->id); ?>" class="deletePhotoFromServer btn btn-danger" data-id="<?php echo e($currentPhoto->id); ?>" type="button">Hapus</button>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <div style="margin-bottom: 16px;" id="attachment-container">

                        </div>
                        <button style='margin-bottom:16px;display:inline-block' id="add-attachment" class="btn btn-primary" type="button" value="Tambah Gambar">Tambah Gambar</button>

                        
                        
                        

                        <br/>
                        <button class="btn btn-success " type="submit" value="Tambah ruangan">Kumpul / Submit</button>

                    </form>


                </div>
                
                    
                        
                        
                            
                            
                            
                            
                            
                        
                    
                    
                        
                            
                            
                            
                            
                            
                            
                            
                            
                        
                        
                            
                                
                                    
                                    
                                
                            
                            
                                
                                    
                                    
                                
                            
                            
                                
                                    
                                    
                                
                            
                            
                                
                                    
                                    
                                
                            
                            
                                
                                    
                                    
                                
                            
                            
                                
                                    
                                    
                                
                            
                            
                                
                                    
                                    
                                
                            
                            
                                
                                    
                                    
                                
                            
                        
                    
                    
                
            </div>
        </div>
    </div>
</div>



<?php $__env->startSection('js'); ?>
    <script>


        $(document).ready(function(){

            $('.deletePhotoFromServer').on('click',function(){
                var id = $(this).data('id');
                // alert(id);


                $('#parentForm').append(`<input hidden name='deletePhoto[]' value="${id}"/>`);
                $(this).parent().remove();

            })
            function deletePhotoFromServer(id){
            }

            var idAttachment = <?php echo e(isset($room) ? $room->getPhotos->where('isMain',false)->count() - 1 : 0); ?>;
            var total = 0;

            if(total >= 2){
                $('#add-attachment').hide();
            }

            $("#add-attachment").on('click',function(){
                $("#attachment-container").append("<div id='attachment-"+idAttachment +"'>" +
                    "<label>Upload Gambar (Max 5000KB)</label>" +
                    "<input type='file' name='photo[]'/>" +

                    "<button type='button' class='btnErase btn btn-danger' data-idtarget='attachment-"+idAttachment++ +"' >Hapus</button>" +
                    "</div>" +
                    "")
                total++;
                if(total > 2){
                    $(this).hide();
                }
            })

            $(document).on('click','.btnErase',function(){
                var target = $(this).data('idtarget');
                // alert(target);
                total--;
                if(total <=2){
                    $('#add-attachment').show();
                }
                $('#'+target).remove();
            })
        })

    </script>
<?php $__env->stopSection(); ?>
