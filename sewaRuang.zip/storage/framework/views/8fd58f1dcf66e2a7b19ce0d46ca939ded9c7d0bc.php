

<?php

    /** @var App\Model\Advertistment $advertisement */

?>

<div class='description-box' rel='2'>
    <div class='contact-box'>
        <div class='title-bar'>
            <div class='inner'  style="border:0px !important;" >

                <h2><?php echo e($isEdit ? "Edit iklan untuk $advertisement->link"  : "Silahkan isi form di bawah ini untuk menambahkan iklan baru"); ?></h2>
                <p></p>
            </div>
        </div>
        <div class='contact-box-content'>
            <div class='inner'>
                <div class=''>


                    <?php echo $__env->make('advertisement.myAdvertisement.rule', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php

                            ?>
                    <form enctype="multipart/form-data" action="<?php echo e(route('post.advertisementForm')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>



                        <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $form->getOutput(); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div style="margin-bottom: 16px;" id="attachment-container">

                        </div>

                        
                        
                        

                        <?php if($isEdit && $advertisement->getIsActive()): ?>
                            <p style="color:tomato;">*Iklan saat ini sedang status aktif, tidak dapat diedit</p>

                        <?php else: ?>
                            <button class="btn btn-success " type="submit" value="Kumpul / Submit">Kumpul / Submit</button>

                        <?php endif; ?>

                    </form>


                </div>
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
            </div>
        </div>
    </div>
</div>



<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){
            var idAttachment = <?php echo e(isset($advertisement) ? $advertisement->getPhoto->count() - 1 : 0); ?>;
            var total = <?php echo e(isset($advertisement) ? $advertisement->getPhoto->count() - 1 : 0); ?>;

            if(total >= 2){
                $('#add-attachment').hide();
            }

            $("#add-attachment").on('click',function(){
                $("#attachment-container").append("<div id='attachment-"+idAttachment +"'>" +
                    "<label>Upload Gambar (Max 5000KB)</label>" +
                    "<input type='file' name='photo[]'/>" +

                    "<button type='button' class='btnErase btn btn-danger' data-idtarget='attachment-"+idAttachment++ +"' >Hapus</button>" +
                    "</div>" +
                    "")
                total++;
                if(total > 2){
                    $(this).hide();
                }
            })

            $(document).on('click','.btnErase',function(){
                var target = $(this).data('idtarget');
                // alert(target);
                total--;
                if(total <=2){
                    $('#add-attachment').show();
                }
                $('#'+target).remove();
            })
        })

    </script>
<?php $__env->stopSection(); ?>
