<?php $__env->startSection('content'); ?>

    <section id='page-title' class='small-height'>
        <section class='container'>
            <section class='row'>
                

                <div class='span8'>
                    <h1>Atur Iklan</h1>
                    <p>Anda dapat melihat iklan-iklan anda di sini</p>
                </div>
            </section>
        </section>
    </section>
    <section class='about-slider'>
        <section class='container'>
            <section class='row'>
                <div class='span9'>

                <?php if(isset($advertisements)): ?>
                        <?php echo $__env->make('advertisement.myAdvertisement.myList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; ?>
                        <?php echo $__env->make('advertisement.myAdvertisement.myAdvertisementForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class='span3'>
                    <div class='description-controls'>
                        <ul>

                            <?php
                                //@
                                    $menus = [
                                        [
                                            'name'=> "Iklan ku",
                                            'isShown' => isset($advertisements),
                                        ],[
                                            'name'=> isset($advertisements) ? 'Pasang iklan baru' : "Edit iklan",
                                            'isShown' => true,
    
    
    
                                        ]
    
                                    ];
                                $i= -1;
                            ?>

                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                

                                <?php if($menu['isShown']): ?>
                                    <?php ($i++); ?>
                                    <?php ($getActive = ($i == 0 ? "active" : "")); ?>
                                    <li><a href="" rel="<?php echo e(($key+1)); ?>" class='<?php echo e($getActive); ?>'><?php echo e($menu['name']); ?></a></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                </div>
            </section>
        </section>
    </section>
    <section class='full-width'>
        <section class='container'>
            <section class='row'>
               <div class="span12">
                   <?php echo $__env->make('advertisement.myAdvertisement.rule', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

               </div>
            </section>
        </section>
    </section>
    <section id='content' class='alternate-bg'>
        <section class='container'>
            <section class='row featured-items'>
                <div class='span12'>
                    <div class='stats5'>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>3k</span>
                                <span class='text'>Items in Database</span>
                            </div>
                        </div>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>300</span>
                                <span class='text'>Happy Clients</span>
                            </div>
                        </div>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>60</span>
                                <span class='text'>Experienced Agents</span>
                            </div>
                        </div>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>58</span>
                                <span class='text'>Searches per hour</span>
                            </div>
                        </div>
                        <div class='stats-box'>
                            <div class='inner'>
                                <span class='number'>786</span>
                                <span class='text'>Months of Activity</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='span12'>
                    <div class="hero-unit">
                        <h1>Sed tortor nulla, vehicula hendrerit pretium</h1>
                        <p>Maecenas accumsan libero sed <strong>nunc ultricies eget molestie</strong> purus blandit. Maecenas lobortis vulputate tortor eget cursus. Curabitur a semper orci.</p>
                        <p>
                            <a class="btn btn-primary btn-large">
                                Learn more
                            </a>
                        </p>
                    </div>
                </div>

            </section>
        </section>
    </section>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>