

<?php
/** @var App\Model\Advertistment[] $advertisements */
/** @var App\Model\Advertistment $advertisement */
///** @var App\Model\Photo $advertisement */

?>


<div class='description-box open' rel='1'>


    <?php $__currentLoopData = $advertisements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class='inner' style="">
            <div class='inner-container'>

                <div style="display:block">

                    <a href="<?php echo e($advertisement->getPhotos->first()->getLarge()); ?>"><div style="max-width:450px;max-height:200px; overflow:hidden; float:left; padding-right: 16px;">
                            <img class="img-responsive" alt="" src="<?php echo e($advertisement->getPhotos->first()->getSmall()); ?>" />

                        </div></a>
                    <h2><?php echo e($advertisement->link); ?></h2>
                    
                    
                    
                    
                        
                        
                                

                            


                    
                    <p style="margin-bottom:-2px;">Status: <?php echo getReadableStatus($advertisement->status); ?></p>

                    <p style="margin-bottom:0px;">Berlaku sampai dengan: <?php echo e($advertisement->validThrough); ?></p>
                    <p style="margin-bottom:0px;">Telah dilihat sebanyak: <?php echo e($advertisement->viewed); ?></p>
                    <p style="margin-bottom:0px;">Berlaku sampai dengan: <?php echo e($advertisement->validThrough); ?></p>

                    
                    <a href="<?php echo e(route('get.advertisementDetail',[$advertisement->id])); ?>">Atur iklan ini</a>
                    <div class='list-container'>
                        <ul class='custom-list'>
                        </ul>
                    </div>
                </div>

                <div style="display:block">
                    
                </div>
                

            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(sizeof($advertisements)== 0): ?>
        <p style="padding:16px;">
            Saat ini anda belum memiliki iklan     yang dipasang
        </p>
        
    <?php endif; ?>
</div>

