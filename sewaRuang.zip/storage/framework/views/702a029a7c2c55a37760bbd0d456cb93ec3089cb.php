<?php

    /** @var App\Model\Room $room */
    /** @var App\Model\Photo $photo */
    /** @var App\Model\Advertistment[] $advertisements */
?>




<?php $__env->startSection('content'); ?>


    <section id='page-title'>
        <section class='container'>
            <section class='row'>
                <div class='span6'>
                    <h1>Property</h1>
                    <ul class="breadcrumb">
                        <li><a href="<?php echo e(route('get.index')); ?>">Home</a> <span class="divider">&ndash;</span></li>
                        <li><a href="">Ruang</a> <span class="divider">&ndash;</span></li>
                        <li class="active"><?php echo e($room->roomName); ?></li>
                    </ul>
                </div>
            </section>
        </section>
    </section>
    <section id='content' class='alternate-bg'>
        <section class='container'>
            <section class='row featured-items'>
                <section class='span9'>
                    <div class='property-box'>
                        <div class='top'>
                            <div class='row'>
                                <div class='left'>
                                    <figure>
                                        <a class="image-link" rel="prettyPhoto[gallery]" href="<?php echo e($room->getPhotos->where('isMain',true)->first()->getLarge()); ?>">

                                            <div style="max-height: 450px">
                                                <img class='img-responsive' src="<?php echo e($room->getPhotos->where('isMain',true)->first()->getSmall()); ?>" alt="" />
                                            </div>
                                        </a>

                                        <div class='banner'></div>
                                    </figure>
                                    <div class='title-line'>
                                        <div class='pull-left'>
                                            <h2><?php echo e($room->roomName); ?></h2> <br />
                                            <h2><?php echo e($room->buildingName); ?></h2> <br />
                                            <h2><?php echo e($room->roomFunction); ?></h2> <br />
                                            <p><?php echo e($room->address); ?>, <?php echo e($room->city); ?></p><br />
                                            <p>No. Telephone ruangan <b><?php echo e($room->providerTelephone); ?></b></p><br />
                                            <p>No. Telephone pemilik akun <b><?php echo e($room->getUser->telephone); ?></b></p>


                                        </div>
                                        <div class='pull-right'>
                                            <span class='price'>Rp. <?php echo e($room->mainPrice); ?> per <?php echo e($room->mainPriceUnit); ?></span>

                                            
                                                

                                            


                                            <?php if($isMyRoom): ?>

                                                <a href="<?php echo e(route('get.editMyRoom',[$room->id])); ?>" style='display:block; margin-top: 12px;' class="btn btn-primary">Edit Ruangan</a>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class='description'>
                                        <p><?php echo e($room->description); ?></p>
                                    </div>
                                    <table class='table table-hover table-bordered'>
                                        <?php
                                        $keyValueContainer = [
                                            [
                                                "key"=>"kapasitas kelas",
                                                "value" => "$room->capacityClass orang",
                                                "initialValue" => $room->capacityClass,
                                            ],[
                                                "key"=>"kapasitas U-Shape",
                                                "value" => "$room->capacityUShape orang",
                                                "initialValue" => $room->capacityUShape,
                                            ],[
                                                "key"=>"kapasitas Teater",
                                                "value" => "$room->capacityTheatre orang",
                                                "initialValue" => $room->capacityTheatre,
                                            ],[
                                                "key"=>"luas",
                                                "value" => "$room->area m<sup>2</sup>",
                                                "initialValue" => $room->area,
                                            ],[
                                                "key"=>"Slot Parkir",
                                                "value" => "$room->parking",
                                                "initialValue" => $room->parking,
                                            ],[
                                                "key"=>"Fasilitas",
                                                "value" => "$room->facility",
                                                "initialValue" => $room->facility,
                                            ],[
                                                "key"=>"Katering",
                                                "value" => "$room->caterings",
                                                "initialValue" => $room->caterings,
                                            ],[
                                                "key"=>"Jumlah ruang",
                                                "value" => "$room->totalRoom",
                                                "initialValue" => $room->totalRoom,
                                            ]
                                        ]
                                        ?>
                                        <?php $__currentLoopData = $keyValueContainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php ($keyValue = (object)$keyValue); ?>

                                            <?php ($keyValue->value = $keyValue->initialValue? $keyValue->value : "Belum ada info"); ?>
                                            <tr>
                                                <td><?php echo e(getNameFormat($keyValue->key)); ?></td>
                                                <td> <?php echo $keyValue->value; ?></td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </table>
                                </div>
                                <div class='right'>
                                    <h3>Gallery <span>(<?php echo e($room->getPhotos->where('isPrimary','false')->count()); ?> photos)</span></h3>
                                    <div class='gallery'>

                                        <?php ($counter = 1); ?>
                                        <?php $__currentLoopData = $room->getPhotos->where('isMain',false)->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div class='line'>
                                                <figure>
                                                    <a class="image-link" rel="prettyPhoto[gallery]" href="<?php echo e($photo->getLarge()); ?>">

                                                    <div style="max-height: 90px; overflow: hidden;">
                                                        <img class="img-responsive" src="<?php echo e($photo->getSmall()); ?>" alt="" />

                                                    </div>
                                                    </a>
                                                </figure>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        
                                            
                                                
                                                    
                                                
                                            
                                            
                                                
                                                    
                                                
                                            
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='bottom'>
                            <div class='inner'>
                                <div class='row'>
                                    <div class='pull-left update-box'>
                                        <p>Update terakhir <a ><?php echo e($room->updated_at); ?></a> by <a><?php echo e($room->getUser->name); ?></a>.</p>
                                    </div>
                                    <div class='pull-right'>
                                        
                                        
                                            
                                            
                                            
                                            
                                            
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    
                        
                            
                                
                                    

                                    
                                    
                                        
                                        
                                        
                                        
                                    
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                </section>

                <aside class="span3">
                    <?php $__currentLoopData = $advertisements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <section class="widget">
                            <a target="_blank" href="//<?php echo e($advertisement->link); ?>"><img class="img-responsive" src="<?php echo e(asset($advertisement->getPhoto->path.$advertisement->getPhoto->nameSm)); ?>" /></a>

                        </section>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </aside>
                
                    
                        
                            
                                
                            
                        
                        
                            
                                
                                    
                                        
                                        
                                    
                                
                                
                                    
                                        
                                        
                                            
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                        
                                            
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                        
                                            
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                        
                                            
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                        
                                            
                                            
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                        
                                        
                                    
                                
                                
                                    
                                        
                                        
                                    
                                
                                
                                    
                                        
                                        
                                    
                                
                            
                        
                    
                
            </section>
        </section>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>