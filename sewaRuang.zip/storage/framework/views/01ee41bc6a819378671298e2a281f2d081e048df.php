<?php

    /** @var App\Model\Room[] $rooms */
    /** @var App\Model\Room $room */
?>


<div class='featured-items-slider'>
    <ul class='slides'>
        <li>
            <div class='row'>

                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php

                        $room->setDefaultPreference();
                    ?>
                    <a href="<?php echo e(route("get.roomDetail",[$room->id])); ?>">
                        <div class='span3 featured-item-wrapper'>
                            <div class='featured-item'>
                                <div class='top'>
                                    <div class='inner-border'>
                                        <div class='inner-padding'>
                                            <figure>
                                                <div>
                                                    <img class="img-responsive" src="<?php echo e($room->getPhotos->where('isMain',true)->first()->getSmall()); ?>" alt=""/>

                                                </div>
                                                <div class='banner'></div>

                                            </figure>
                                            <h3><?php echo e($room->roomFunction); ?></h3>
                                            <p><?php echo e($room->buildingName); ?> - <?php echo e($room->roomName); ?>, <?php echo e($room->city); ?></p>
                                            

                                        </div>
                                    </div>
                                    <i class='bubble'></i>
                                </div>
                                <div class='bottom'>
                                    <div class='inner-border'>
                                        <div class='inner-padding'>
                                            <p><?php echo e($room->address); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class='star-rating'>
                                <button class='star blue'>1 Star</button>
                                <button class='star active'>2 Star</button>
                                <button class='star active'>3 Star</button>
                                <button class='star'>4 Star</button>
                                <button class='star'>5 Star</button>
                            </div>
                            <div class='price-wrapper'>
                                <div class='price'>Rp. <?php echo e(($room->mainPrice)); ?></div>
                                <div class='rate'>/jam</div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </li>

    </ul>
</div>