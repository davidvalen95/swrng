<?php
/**
    @var CForm $form;
    @var CForm[] $forms;
*/

?>




<?php $__env->startSection('content'); ?>

        <div class="span8 center-block inner " style="background: white; padding: 20px; margin: 20px auto; display: inline-block;" >
            <form enctype="multipart/form-data" action="<?php echo e(route('post.advertisementPayment')); ?>" method="post">
                <?php echo e(csrf_field()); ?>



                <?php

                    $photo = new CForm("Bukti pembayaran","photo");
                    $photo->setInputTypePhoto();
                    $photo->bottomDescription = "Silahkan foto bukti pembayaran yang sesuai dengan harga dan berita acara";
                    $photo->isRequired = true;

                    $invoice = new CForm("Nomer Invoice / berita acara","invoice");
                    $invoice->isRequired = true;
                    $invoice->value =  Request::get('invoice');



                    $forms = [$photo, $invoice];
                ?>
                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $form->getOutput(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div style="margin-bottom: 16px;" id="attachment-container">

                </div>

                <p><?php echo captcha_img(); ?></p>
                <label>Captcha</label>
                <p><input required type="text" name="captcha"></p>
                <button class="btn btn-success " type="submit" value="Kumpul / Submit">Kumpul / Submit</button>

            </form>
        </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>