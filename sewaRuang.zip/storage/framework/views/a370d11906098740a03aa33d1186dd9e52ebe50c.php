<?php

    /** @var App\Model\Room[] $rooms */
    /** @var App\Model\Room $room */



?>



<?php $__env->startSection('content'); ?>


    <section id='homepage-slider'>
        <div class='controls-wrapper'>
            <section class='container'>
                <section class='row'>
                    <div class='controls hidden-phone'>
                        <a href="#" class='prev'>Previous</a>
                        <a href="#" class='next'>Next</a>
                    </div>
                </section>
            </section>
        </div>
        <section class='slider-wrapper'>
            <div class='homepage-slider hidden-phone'>
                <ul class='slides'>
                    <li>
                        <img src="img/photos/4834201449_2801d96045_o-1.jpg" alt="" class='bg-image'/>
                        <div class='container'>
                            <div class='row'>
                                <div class='span12'>
                                    <div class='text-box span6'>
                                        <h1><a href="property.html">Great place for artists!</a></h1>
                                        <p>In sit amet arcu quis dolor adipiscing laoreet sed sit amet arcu. Proin non
                                            adipiscing felis.</p>
                                    </div>
                                    <div class='description'>
                                        <div class='left'>
                                            <div class='title'>
                                                <div class='big'>Seaway house</div>
                                                <div class='small'>Los Angeles, CA</div>
                                            </div>
                                            <div class='rooms'> 3 bedrooms - 2 bathrooms</div>
                                        </div>
                                        <div class='right'>
                                            <div class='price'>
                                                <div class='number'> $1200</div>
                                                <div class='rate'> per month</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <img src="img/photos/4834826842_7483d905eb_o.jpg" alt="" class='bg-image'/>
                        <div class='container'>
                            <div class='row'>
                                <div class='span12'>
                                    <div class='text-box span6'>
                                        <h1><a href="property.html">4 bedrooms apartment for sale!</a></h1>
                                        <p>Pellentesque viverra lacus quis lacus viverra mattis. Sed sed nisi erat, sed
                                            consectetur metus.</p>
                                    </div>
                                    <div class='description'>
                                        <div class='left'>
                                            <div class='title'>
                                                <div class='big'>Seaway house</div>
                                                <div class='small'>Los Angeles, CA</div>
                                            </div>
                                            <div class='rooms'> 4 bedrooms - 5 bathrooms</div>
                                        </div>
                                        <div class='right'>
                                            <div class='price'>
                                                <div class='number'> $32000</div>
                                                <div class='rate'> per year</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
    </section>

    <section id='main' role='main'>
        <section class='container'>
            <section class='row tab-finder'>
                <div class='span12'>
                    <div class="tabbable">
                        
                            
                           
                        
                        <div class="tab-content">
                            <div class="tab-pane active" id="tab1">
                                <div class='inner'>

                                    <?php


                                    $function = new CForm("Fungsi","search[function]");
                                    $function->isButton = true;
                                    $function->setInputTypeSelect([],\App\Model\FungsiRuang::all());

                                    $city = new CForm("Kota","search[city]");
                                    $city->isButton = true;
                                    $city->setInputTypeSelect(["surabaya","jakarta","medan"]);




                                    $forms = [$function,$city];
                                    ?>
                                    <form action="" method="GET">
                                        
                                               
                                        

                                        <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $form->getOutput(); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                               
                                        
                                        
                                               
                                        <button syle='display:block;' type="submit" class='btn btn-primary search-property'><i
                                                    class="icon-search icon-white"></i> Cari Ruang
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <div class="tab-pane" id="tab2">
                                <div class='inner'>
                                    <form action="#">
                                        <input type="text" name='search-string' class='search-string'
                                               placeholder="eg. 'Miami', 'Los Angeles'"/>
                                        <input type="text" name='search-year' class='search-year' placeholder="Year"/>
                                        <select name="search-bedrooms" class='span2 selectpicker search-select'>
                                            <option>Bedrooms</option>
                                            <option>1</option>
                                            <option>2</option>
                                        </select>
                                        <select name="search-bathrooms" class='span2 selectpicker search-select'>
                                            <option>Bathrooms</option>
                                            <option>1</option>
                                            <option>2</option>
                                        </select>
                                        <input type="text" name='search-min-price' class='span2 search-price no-margin'
                                               placeholder="Min. Price"/>
                                        <span class='line-divider'>&ndash;</span>
                                        <input type="text" name='search-max-price' class='span2 search-price'
                                               placeholder="Max. Price"/>
                                        <button type="submit" class='btn btn-primary search-property'><i
                                                    class="icon-search icon-white"></i> Search Property
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <div class="tab-pane" id="tab3">
                                <div class='inner'>
                                    <form action="#">
                                        <input type="text" name='search-string' class='search-string'
                                               placeholder="eg. 'Miami', 'Los Angeles'"/>
                                        <input type="text" name='search-year' class='search-year' placeholder="Year"/>
                                        <select name="search-bedrooms" class='span2 selectpicker search-select'>
                                            <option>Bedrooms</option>
                                            <option>1</option>
                                            <option>2</option>
                                        </select>
                                        <select name="search-bathrooms" class='span2 selectpicker search-select'>
                                            <option>Bathrooms</option>
                                            <option>1</option>
                                            <option>2</option>
                                        </select>
                                        <input type="text" name='search-min-price' class='span2 search-price no-margin'
                                               placeholder="Min. Price"/>
                                        <span class='line-divider'>&ndash;</span>
                                        <input type="text" name='search-max-price' class='span2 search-price'
                                               placeholder="Max. Price"/>
                                        <button type="submit" class='btn btn-primary search-property'><i
                                                    class="icon-search icon-white"></i> Search Property
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <div class="tab-pane" id="tab4">
                                <div class='inner'>
                                    <form action="#">
                                        <input type="text" name='search-string' class='search-string'
                                               placeholder="eg. 'Miami', 'Los Angeles'"/>
                                        <input type="text" name='search-year' class='search-year' placeholder="Year"/>
                                        <select name="search-bedrooms" class='span2 selectpicker search-select'>
                                            <option>Bedrooms</option>
                                            <option>1</option>
                                            <option>2</option>
                                        </select>
                                        <select name="search-bathrooms" class='span2 selectpicker search-select'>
                                            <option>Bathrooms</option>
                                            <option>1</option>
                                            <option>2</option>
                                        </select>
                                        <input type="text" name='search-min-price' class='span2 search-price no-margin'
                                               placeholder="Min. Price"/>
                                        <span class='line-divider'>&ndash;</span>
                                        <input type="text" name='search-max-price' class='span2 search-price'
                                               placeholder="Max. Price"/>
                                        <button type="submit" class='btn btn-primary search-property'><i
                                                    class="icon-search icon-white"></i> Search Property
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class='row featured-items'>
                <div class='span12'>
                    <h2>Featured Items</h2>
                    <div class='controls'>
                        <a href="#" class='prev'>Previous</a>
                        <a href="#" class='next'>Next</a>
                    </div>


                    
                    <div class='featured-items-slider'>
                        <ul class='slides'>
                            <li>
                                <div class='row'>

                                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php

                                        $room->setDefaultPreference();
                                        ?>
                                    <a href="<?php echo e(route("get.roomDetail",[$room->id])); ?>">
                                        <div class='span3 featured-item-wrapper'>
                                            <div class='featured-item'>
                                                <div class='top'>
                                                    <div class='inner-border'>
                                                        <div class='inner-padding'>
                                                            <figure>
                                                                <img src="<?php echo e($room->getPhotos->where('isMain',true)->first()->getSmall())); ?>" alt=""/>
                                                                <div class='banner'></div>

                                                            </figure>
                                                            <h3>Fungsi: <?php echo e($room->function); ?></h3>
                                                            <p>Nama Gedung: <?php echo e($room->buildingName); ?></p>
                                                            <p>Kota: <?php echo e($room->city); ?></p>
                                                            
                                                            
                                                            
                                                            <p>Kapasitas(orang): <?php echo e($room->capacity); ?></p>

                                                        </div>
                                                    </div>
                                                    <i class='bubble'></i>
                                                </div>
                                                <div class='bottom'>
                                                    <div class='inner-border'>
                                                        <div class='inner-padding'>
                                                            <p>3 beds + 1 bath + 100 sqft</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='star-rating'>
                                                <button class='star blue'>1 Star</button>
                                                <button class='star active'>2 Star</button>
                                                <button class='star active'>3 Star</button>
                                                <button class='star'>4 Star</button>
                                                <button class='star'>5 Star</button>
                                            </div>
                                            <div class='price-wrapper'>
                                                <div class='price'>Rp. <?php echo e(($room->mainPrice)); ?></div>
                                                <div class='rate'>/jam</div>
                                            </div>
                                        </div>
                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                            </li>

                        </ul>
                    </div>
                </div>
                <i class='content-bubble'></i>
            </section>
        </section>
    </section>
    <footer>
        <section class='container'>
            <section class='row'>
                <div class='span4 footer-widget'>
                    <h2>About Us</h2>
                    <p>Donec ac diam nec magna dignissim porta ut eu nulla. Cras neque metus, dictum et congue ac,
                        tristique eget ante. In hac habitasse platea dictumst.</p>
                    <p>Quisque tincidunt ornare sapien, at commodo ante tristique non. Integer id tellus nisl. Donec
                        eget nunc eget odio malesuada egestas.</p>
                    <a href="#" class='read-more'>Learn More</a>
                </div>
                <div class='span4 footer-widget'>
                    <h2>Recent News</h2>
                    <div class='blog-style'>
                        <article>
                            <div class='date-box'>
                                <div class='day'>20</div>
                                <div class='month'>mar</div>
                            </div>
                            <div class='text-box'>
                                <h3><a href="post.html">How to Choose Property</a></h3>
                                <span class='author'>posted by admin</span>
                                <div class='excerpt'>
                                    <p>In porttitor augue vel velit luctus at scelerisque nisi dictum. Ut tempus
                                        dignissim mi, at gravida leo.</p>
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class='date-box'>
                                <div class='day'>16</div>
                                <div class='month'>mar</div>
                            </div>
                            <div class='text-box'>
                                <h3><a href="post.html">Real Estate of Future</a></h3>
                                <span class='author'>posted by admin</span>
                                <div class='excerpt'>
                                    <p>In porttitor augue vel velit luctus at scelerisque nisi dictum. Ut tempus
                                        dignissim mi, at gravida leo.</p>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
                <div class='span4 footer-widget'>
                    <h2>Testimonials</h2>
                    <div class='testimonial-box'>
                        <div class='controls'>
                            <a href="#" class='prev'>Previous</a>
                            <a href="#" class='next'>Next</a>
                        </div>
                        <ul class='slides'>
                            <li>
                                <div class='slide-box'>
                                    <div class='text-box'>
                                        <div class='inner'>
                                            <p>"Quisque venenatis dui vitae augue accumsan sed blandit lectus pretium.
                                                Vivamus at urna ut est faucibus ornare in quis lacus. Praesent erat
                                                nulla, venenatis ac consequat vel, vestibulum id massa."</p>
                                        </div>
                                        <i class='bubble'></i>
                                    </div>
                                    <div class='author-box'>
                                        <figure></figure>
                                        <div class='texts'>
                                            <span class='name'>John Doe</span> <br/>
                                            <span class='position'>Company name</span>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class='slide-box'>
                                    <div class='text-box'>
                                        <div class='inner'>
                                            <p>Donec ac diam nec magna dignissim porta ut eu nulla. Cras neque metus,
                                                dictum et congue ac, tristique eget ante. In hac habitasse platea
                                                dictumst.</p>
                                        </div>
                                        <i class='bubble'></i>
                                    </div>
                                    <div class='author-box'>
                                        <figure></figure>
                                        <div class='texts'>
                                            <span class='name'>John Doe</span> <br/>
                                            <span class='position'>Company name</span>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <i class='footer-bubble'></i>
            </section>
        </section>
    </footer>
    <section id='sub-footer'>
        <section class='container'>
            <section class='row'>
                <div class='span3'>
                    <figure class='logo'>
                        <a href="index-2.html">
                            <img src="img/logo-footer.png" alt=""/>
                        </a>
                    </figure>
                </div>
                <div class='span6'>
                    <div class='copyright'>
                        <p>&copy; 2013 Unreal Estate. All rights reserved. Developed by <a href="http://teothemes.com/">TeoThemes</a>
                        </p>
                    </div>
                </div>
                <div class='span3'>
                    <div class='social-icons'>
                        <a href="#" class='be'>Be</a>
                        <a href="#" class='star'>Star</a>
                        <a href="#" class='pinterest'>Pinterest</a>
                        <a href="#" class='facebook'>Facebook</a>
                        <a href="#" class='twitter'>Twitter</a>
                    </div>
                </div>
            </section>
        </section>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>