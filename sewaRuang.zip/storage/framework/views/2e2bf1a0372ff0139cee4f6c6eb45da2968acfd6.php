<?php $__env->startSection('content'); ?>
    <div class='contact-box-content'>
        <div class='inner'>
            <div class="span3">

            </div>
            <div class='span6'>
                <div class="text-center">
                    <p>Hallo <?php echo e($user->name); ?></p>
                    <h3>Ubah password</h3>

                </div>

                <?php

                        ?>
                <form enctype="multipart/form-data" action="<?php echo e(route('post.resetPassword')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>



                    <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $form->getOutput(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div style="margin-bottom: 16px;" id="attachment-container">

                    </div>

                    <button class="btn btn-success " type="submit" value="Kumpul / Submit">Kumpul / Submit</button>

                </form>


            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>