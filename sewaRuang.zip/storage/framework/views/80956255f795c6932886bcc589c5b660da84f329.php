







<section id='hidden-header'>
    <section class='container'>
        <section class='row contact-form'>

            <div class='span6' >
                <div class='login-form top-form'>
                    <h2>Contact Form</h2>

                    <p>Quisque tincidunt ornare sapien, at commodo ante tristique non. Integer id tellus nisl. Donec eget nunc eget odio malesuada egestas.</p>

                    <form action="#" class='row'>
                        <div class='span3'>
                            <input type="text" class='input-block-level' name='name' placeholder="Name"/>
                        </div>
                        <div class='span3'>
                            <input type="email" class='input-block-level' name='email' placeholder="Email"/>

                        </div>
                        <div class='span6'>
                            <textarea name="message" class='input-block-level' rows="5" placeholder="Message"></textarea>
                            <input type="submit" name='submit' value='Send' class='btn btn-primary'/>
                        </div>
                    </form>
                </div>
            </div>
            <div class='span6'>
                <div class='top-form addresses'>
                    <h2>Location & Address</h2>

                    <div class='map-container'>
                        <iframe width="100%" height="180" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"
                                src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;q=Rainer+Ave,+Rowland+Heights,+Los+Angeles,+California+91748&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=42.495706,93.076172&amp;t=m&amp;ie=UTF8&amp;geocode=FcByBgIdVe34-A&amp;split=0&amp;hq=&amp;hnear=Rainer+Ave,+Rowland+Heights,+Los+Angeles,+California+91748&amp;ll=33.977033,-117.904072&amp;spn=0.024912,0.036478&amp;z=14&amp;iwloc=A&amp;output=embed"></iframe>
                    </div>
                    <div class='row'>
                        <div class='span3'>
                            <address>
                                <strong>Head Office</strong> <br/>
                                Reiner street 5, Los Angeles, CA 48523 <br/>
                                Phone: +32 (0)2 494 01 28 <br/>
                                Email: hidentica@gmail.com <br/>
                            </address>
                        </div>
                        <div class='span3'>
                            <address>
                                <strong>Representative</strong> <br/>
                                Winsont F. st. 10, New York, 48523 <br/>
                                Phone: +32 (0)2 494 01 28 <br/>
                                Email: hidentica@gmail.com <br/>
                            </address>
                        </div>
                    </div>
                </div>
            </div>





        </section>

        <?php if(!Auth::check()): ?>
        <section class='row profile-form'>
            <div class='span6'>
                <div class='login-form top-form'>
                    <h2>Login</h2>


                    <form method="POST"action="<?php echo e(route("post.login")); ?>"  class='row'>
                        <?php echo e(csrf_field()); ?>

                        <div class='span3'>
                            <input type="email" class='input-block-level' name='email' placeholder="Email"/>
                        </div>
                        <div class='span3'>
                            <input type="password" class='input-block-level' name='password' placeholder="Password"/>
                            <input type="submit" name='submit' value='Login' class='btn btn-primary'/>
                        </div>
                    </form>


                    <h2 style="margin-top: 16px;">Lupa Password</h2>

                    <form method="POST" action="<?php echo e(route("post.requestReset")); ?>"  class='row'>
                        <?php echo e(csrf_field()); ?>

                        <div class='span6'>
                            <input type="email" class='input-block-level' name='email' placeholder="Email"/>

                        </div>
                        <div class="span3">

                        </div>
                        <div class='span3'>
                            <input type="submit" name='submit' value='Reset Password' class='btn btn-primary'/>

                        </div>
                    </form>
                </div>
            </div>


            <div class='span6'>
                <div class='login-form top-form'>
                    <h2>Register</h2>

                    <form method="POST"action="<?php echo e(route("post.register")); ?>" class='row'>
                        <?php echo e(csrf_field()); ?>

                        <div class='span3'>
                            <?php
                                $cities = App\Model\City::all()->sortBy("name")
                            ?>
                            <input value="<?php echo e(old('email')); ?>" required type="email" class='input-block-level' name='email' placeholder="Email"/>


                            <input value="<?php echo e(old('password')); ?>" type="password" class='input-block-level' name='password' placeholder="Password"/>
                            <input value="<?php echo e(old('passowrd_confirmation')); ?>" required type="password" class='input-block-level' name='password_confirmation' placeholder="Confirm Password"/>

                        </div>
                        <div class='span3'>
                            <input value="<?php echo e(old('name')); ?>" required type="text" class='input-block-level' name='name' placeholder="Name"/>

                            <input value="<?php echo e(old('telephone')); ?>" required type="text" class='input-block-level' name='telephone' placeholder="Telephone"/>
                            
                                
                                    
                                
                            
                            <input placeholder="Kota" id="city" name="city" />
                            <input  required type="submit" name='submit' value='Register' class='btn btn-primary'/>
                        </div>
                    </form>
                </div>
            </div>
        </section>

        <?php else: ?>

                <?php

                $user = Auth::user();
                $user->setDefaultPreference();
                ?>

                <section class='row profile-form'>
                    <div class='span6'>
                        <div class='login-form top-form'>
                            <h2><?php echo e($user->name); ?></h2>

                            <p></p>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input style="float:left;" type="submit" value="logout">
                            </form>
                        </div>
                    </div>


                    <div class='span6'>

                    </div>
                </section>

        <?php endif; ?>

    </section>
</section>




<header>
    <section class='container'>
        <section class='row'>
            
                
                    
                        
                    
                
            
            <div class='span9'>
                <nav class='main-nav'>
                    <ul>
                        <li><a href="<?php echo e(route('get.index')); ?>">Home</a></li>
                        
                        
                            
                            
                                
                                
                                    
                                    
                                        
                                        
                                        
                                        
                                    
                                
                                
                                    
                                    
                                        
                                        
                                        
                                        
                                    
                                
                                
                            
                        
                        
                            
                            
                                
                            
                        
                        
                            
                            
                                
                            
                        
                        
                            
                            
                                
                                
                                
                                
                            
                        



                        <?php if(Auth::check()): ?>
                            <li>
                                <a href="<?php echo e(route('get.myRoom')); ?>">Atur Ruangan</a>

                            </li>

                            <li>
                                <a href="<?php echo e(route('get.myAdvertisement')); ?>">Atur Iklan</a>

                            </li>

                            <li>
                                <a href="<?php echo e(route('get.advertisementPayment')); ?>">Konfirmasi pembayaran Iklan</a>

                            </li>
                            <span style="display:inline-block;color:rgba(255,255,255,0.5);font-weight: bold;padding: 16px 8px 0px" class="custom-tooltip"><?php echo e(Auth::user()->name); ?></span>

                            <form style="display:inline-block" method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input style="background:transparent; border:none;shadown:none;outline: none; color: tomato;font-weight: bold;margin-top: -4px;" type="submit" value="logout">
                            </form>

                        <?php endif; ?>



                    </ul>
                </nav>
            </div>
            <div class='span3'>
                <div class='header-buttons'>
                    
                    <?php if(!Auth::check()): ?>
                        
                        <a href="#" class='profile custom-tooltip' title="Go to My Profile">Profile</a>

                    <?php endif; ?>

                    <a href="#" class='contact custom-tooltip' title='Got to Contact Form'>Contact</a>
                </div>
            </div>
        </section>
    </section>
</header>


    <div class="alert alert-danger text-center">
        <ul>
            <?php if($errors->any()): ?>

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
                

            <?php if(Session::has('dangerNotification')): ?>
                    <li><?php echo e(Session::get('dangerNotification')); ?></li>
            <?php endif; ?>
        </ul>

    </div>

<div class="alert alert-success text-center">
    <ul>
        
        <?php if(Session::has('successNotification')): ?>
            <li><?php echo e(Session::get('successNotification')); ?></li>
        <?php endif; ?>

    </ul>
</div>

