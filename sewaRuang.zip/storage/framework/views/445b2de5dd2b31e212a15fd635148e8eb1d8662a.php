







<section id='hidden-header'>
    <section class='container'>
        <section class='row contact-form'>
            <div class='span6'>
                <div class='login-form top-form'>
                    <h2>Contact Form</h2>

                    <p>Quisque tincidunt ornare sapien, at commodo ante tristique non. Integer id tellus nisl. Donec eget nunc eget odio malesuada egestas.</p>

                    <form action="#" class='row'>
                        <div class='span3'>
                            <input type="text" class='input-block-level' name='name' placeholder="Name"/>
                        </div>
                        <div class='span3'>
                            <input type="email" class='input-block-level' name='email' placeholder="Email"/>

                        </div>
                        <div class='span6'>
                            <textarea name="message" class='input-block-level' rows="5" placeholder="Message"></textarea>
                            <input type="submit" name='submit' value='Send' class='btn btn-primary'/>
                        </div>
                    </form>
                </div>
            </div>
            <div class='span6'>
                <div class='top-form addresses'>
                    <h2>Location & Address</h2>

                    <div class='map-container'>
                        <iframe width="100%" height="180" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"
                                src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;q=Rainer+Ave,+Rowland+Heights,+Los+Angeles,+California+91748&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=42.495706,93.076172&amp;t=m&amp;ie=UTF8&amp;geocode=FcByBgIdVe34-A&amp;split=0&amp;hq=&amp;hnear=Rainer+Ave,+Rowland+Heights,+Los+Angeles,+California+91748&amp;ll=33.977033,-117.904072&amp;spn=0.024912,0.036478&amp;z=14&amp;iwloc=A&amp;output=embed"></iframe>
                    </div>
                    <div class='row'>
                        <div class='span3'>
                            <address>
                                <strong>Head Office</strong> <br/>
                                Reiner street 5, Los Angeles, CA 48523 <br/>
                                Phone: +32 (0)2 494 01 28 <br/>
                                Email: hidentica@gmail.com <br/>
                            </address>
                        </div>
                        <div class='span3'>
                            <address>
                                <strong>Representative</strong> <br/>
                                Winsont F. st. 10, New York, 48523 <br/>
                                Phone: +32 (0)2 494 01 28 <br/>
                                Email: hidentica@gmail.com <br/>
                            </address>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class='row profile-form'>
            <div class='span6'>
                <div class='login-form top-form'>
                    <h2>Login</h2>

                    <p>Quisque tincidunt ornare sapien, at commodo ante tristique non. Integer id tellus nisl. Donec eget nunc eget odio malesuada egestas.</p>

                    <form method="POST"action="<?php echo e(route("post.login")); ?>" action="#" class='row'>
                        <?php echo e(csrf_field()); ?>

                        <div class='span3'>
                            <input type="email" class='input-block-level' name='email' placeholder="Email"/>
                        </div>
                        <div class='span3'>
                            <input type="password" class='input-block-level' name='password' placeholder="Password"/>
                            <input type="submit" name='submit' value='Login' class='btn btn-primary'/>
                        </div>
                    </form>
                </div>
            </div>
            <div class='span6'>
                <div class='login-form top-form'>
                    <h2>Register</h2>

                    <p>Quisque tincidunt ornare sapien, at commodo ante tristique non. Integer id tellus nisl. Donec eget nunc eget odio malesuada egestas.</p>

                    <form method="POST"action="<?php echo e(route("post.register")); ?>" class='row'>
                        <?php echo e(csrf_field()); ?>

                        <div class='span3'>
                            <input value="<?php echo e(old('name')); ?>" required type="text" class='input-block-level' name='name' placeholder="Name"/>
                            <?php ($cities = App\Model\City::all()->sortBy("name")); ?>
                            <input value="<?php echo e(old('email')); ?>" required type="email" class='input-block-level' name='email' placeholder="Email"/>


                            <input value="<?php echo e(old('password')); ?>" type="password" class='input-block-level' name='password' placeholder="Password"/>

                        </div>
                        <div class='span3'>
                            <input value="<?php echo e(old('telephone')); ?>" required type="text" class='input-block-level' name='telephone' placeholder="(Dengan Nomor Region) Telephone"/>
                            <input value="<?php echo e(old('passowrd_confirmation')); ?>" required type="password" class='input-block-level' name='password_confirmation' placeholder="Confirm Password"/>
                            <select value="<?php echo e(old('city')); ?>" required type="select" class='input-block-level selectpicker' name='city' placeholder="City">
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->name); ?>"><?php echo e(ucwords($city->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input  required type="submit" name='submit' value='Register' class='btn btn-primary'/>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>
</section>




<header>
    <section class='container'>
        <section class='row'>
            <div class='span3'>
                <figure class='logo'>
                    <a href="index-2.html">
                        <img src="img/logo.png" alt=""/>
                    </a>
                </figure>
            </div>
            <div class='span6'>
                <nav class='main-nav'>
                    <ul>
                        <li><a href="index-2.html">Home</a></li>
                        <li class='active'><a href="about.html">About</a></li>
                        <li>
                            <a href="property.html">Property</a>
                            <ul class='dropdown-menu'>
                                <li class='first-element'><a href="search-location.html">For Sale</a></li>
                                <li class='dropdown-submenu'>
                                    <a href="search-list.html"></a>
                                    <ul class='dropdown-menu'>
                                        <li class='first-element'><a href="search-grid-no-form.html">Sub menu item 1</a></li>
                                        <li><a href="search-grid.html">Sub menu item 2</a></li>
                                        <li><a href="search-grid.html">Sub menu item 3</a></li>
                                        <li class='last-element'><a href="search-grid.html">Sub menu item 4</a></li>
                                    </ul>
                                </li>
                                <li class='dropdown-submenu'>
                                    <a href="search-location.html">Forclosures</a>
                                    <ul class='dropdown-menu'>
                                        <li class='first-element'><a href="search-grid.html">Sub menu item 1</a></li>
                                        <li><a href="search-grid-no-form.html">Sub menu item 2</a></li>
                                        <li><a href="search-grid-no-form.html">Sub menu item 3</a></li>
                                        <li class='last-element'><a href="search-grid.html">Sub menu item 4</a></li>
                                    </ul>
                                </li>
                                <li class='last-element'><a href="search-grid-no-form.html">New Homes</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="agents.html">Agents</a>
                            <ul class='dropdown-menu'>
                                <li><a href="agent.html">Single agent</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="blog.html">Blog</a>
                            <ul class='dropdown-menu'>
                                <li><a href="post.html">Single post</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="search-grid-no-form.html">Search</a>
                            <ul class='dropdown-menu'>
                                <li><a href="search-grid-no-form.html">Search grid no form</a></li>
                                <li><a href="search-grid.html">Search grid with form</a></li>
                                <li><a href="search-list.html">Search list</a></li>
                                <li><a href="search-location.html">Search with location</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class='span3'>
                <div class='header-buttons'>
                    <a href="#" class='add custom-tooltip' title="Add something">Add</a>
                    <a href="#" class='profile custom-tooltip' title="Go to My Profile">Profile</a>
                    <a href="#" class='contact custom-tooltip' title='Got to Contact Form'>Contact</a>
                </div>
            </div>
        </section>
    </section>
</header>


    <div class="alert alert-danger text-center">
        <ul>
            <?php if($errors->any()): ?>

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
                

            <?php if(Session::has('dangerNotification')): ?>
                    <li><?php echo e(Session::get('dangerNotification')); ?></li>
            <?php endif; ?>
        </ul>

    </div>

<div class="alert alert-success text-center">
    <ul>
        
        <?php if(Session::has('successNotification')): ?>
            <li><?php echo e(Session::get('successNotification')); ?></li>
        <?php endif; ?>

    </ul>
</div>

