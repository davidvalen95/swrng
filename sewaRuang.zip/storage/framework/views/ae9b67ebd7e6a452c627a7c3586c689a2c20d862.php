<?php

/** @var App\Model\Advertistment $advertisement */
/** @var App\Model\AdvertistmentHistoryDescription $history $lastUnpaid */
/** @var App\Model\AdvertistmentPayment $paymentHistory */

///** @var App\Model\Photo $photo */
?>




<?php $__env->startSection('content'); ?>


    <section id='page-title'>
        <section class='container'>
            <section class='row'>
                <div class='span6'>
                    <h1>Atur iklan</h1>
                    <ul class="breadcrumb">
                        <li><a href="<?php echo e(route('get.index')); ?>">Home</a> <span class="divider">&ndash;</span></li>
                        <li><a href="">Iklan</a> <span class="divider">&ndash;</span></li>
                        
                    </ul>
                </div>
            </section>
        </section>
    </section>
    <section id='content' class='alternate-bg'>
        <section class='container'>
            <section class='row featured-items'>
                <section class='span9'>
                    <div class='property-box'>
                        <div class='top'>
                            <div class='row'>
                                <div class='left'>
                                    <h1><?php echo e($advertisement->description); ?></h1>

                                    <figure>
                                        <a rel="prettyPhoto[gallery]" href="<?php echo e($advertisement->getPhotos->first()->getLarge()); ?>">

                                            <div style="max-height: 450px">
                                                <img class='img-responsive' src="<?php echo e($advertisement->getPhotos->first()->getSmall()); ?>" alt="" />
                                            </div>
                                        </a>

                                        <div class='banner'></div>
                                    </figure>
                                    <div class='title-line'>
                                        <div class='pull-left'>
                                            <?php
                                                $lastUnpaid = $advertisement->getLastUnpaidInvoice();
                                            ?>

                                            <?php if($lastUnpaid): ?>
                                                <div>Nomer Invoice yang harus dibayarkan
                                                    <b style="color:tomato;font-size: 24px">

                                                        <?php echo e($lastUnpaid ? $lastUnpaid->invoice : ""); ?>

                                                    </b>
                                                    <a href="<?php echo e(route('get.advertisementPayment',['invoice'=>$lastUnpaid->invoice])); ?>">Klik untuk konfirmasi pembayaran</a>

                                                </div><br/>
                                            <?php endif; ?>

                                            
                                            
                                            
                                            
                                            <p>Link iklan: <b><?php echo e($advertisement->link); ?></b></p><br />
                                            <p>Target kota: <b><?php echo e($advertisement->targetCity); ?></b></p><br />
                                            <p>Status iklan: <?php echo getReadableStatus($advertisement->status); ?></p><br />
                                            <p>Berlaku sampai: <b><?php echo e(getReadableStatus($advertisement->validThrough)); ?></b></p><br />
                                            


                                        </div>

                                    </div>
                                    <div class='description'>
                                        <p><?php echo e($advertisement->description); ?></p>
                                    </div>

                                    <table class='table table-hover table-bordered'>
                                        <?php
                                            //debug();
                                        ?>
                                        <?php $__currentLoopData = $advertisement->getHistories->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $history->setDefaultPreference();
                                            ?>

                                            <a class="btn btn-primary" href="<?php echo e(route('get.editAdvertisement',[$advertisement->id])); ?>">Edit iklan ini</a>
                                            <thead>
                                            <tr>
                                                <th>Tanggal</th>
                                                <th>Status</th>
                                                <th>Keterangan</th>
                                                <th>Nomer Invoice</th>
                                                <th>Harga</th>
                                                <th>Status Invoice</th>
                                                <th>Bukti pembayaran</th>
                                            </tr>
                                            </thead>

                                            <tr>
                                                <td><?php echo e($history->created_at); ?></td>
                                                <td><?php echo getReadableStatus($history->status); ?></td>
                                                <td><?php echo e($history->description); ?></td>
                                                <td><?php echo e($history->invoice); ?></td>
                                                <td><?php echo e($history->price); ?></td>
                                                <td><?php echo e($history->isPaid ? "Telah dibayar" : "Belum dibayar"); ?></td>

                                                <td>
                                                    <?php ($i=1); ?>
                                                    <?php $__currentLoopData = $history->getPayment(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                        <a href="<?php echo e(asset($paymentHistory->getPhotos->first()->getSmall())); ?>">Bukti-<?php echo e($i++); ?></a><br/>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </table>
                                </div>

                            </div>
                        </div>

                    </div>

                 
                </section>
             
            </section>
        </section>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>